﻿
namespace PoC
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.profileButton = new System.Windows.Forms.Button();
            this.showEvidence = new System.Windows.Forms.Button();
            this.viewStudents = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // profileButton
            // 
            this.profileButton.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileButton.Location = new System.Drawing.Point(12, 12);
            this.profileButton.Name = "profileButton";
            this.profileButton.Size = new System.Drawing.Size(108, 45);
            this.profileButton.TabIndex = 7;
            this.profileButton.Text = "Perfil";
            this.profileButton.UseVisualStyleBackColor = true;
            this.profileButton.Click += new System.EventHandler(this.viewProfile);
            // 
            // showEvidence
            // 
            this.showEvidence.BackColor = System.Drawing.Color.LightGreen;
            this.showEvidence.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.showEvidence.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showEvidence.Location = new System.Drawing.Point(116, 92);
            this.showEvidence.Name = "showEvidence";
            this.showEvidence.Size = new System.Drawing.Size(193, 70);
            this.showEvidence.TabIndex = 8;
            this.showEvidence.Text = "Visualizar Evidencia";
            this.showEvidence.UseVisualStyleBackColor = false;
            this.showEvidence.Click += new System.EventHandler(this.viewEvidence);
            // 
            // viewStudents
            // 
            this.viewStudents.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.viewStudents.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewStudents.Location = new System.Drawing.Point(116, 196);
            this.viewStudents.Name = "viewStudents";
            this.viewStudents.Size = new System.Drawing.Size(193, 45);
            this.viewStudents.TabIndex = 10;
            this.viewStudents.Text = "Estudiantes";
            this.viewStudents.UseVisualStyleBackColor = false;
            this.viewStudents.Click += new System.EventHandler(this.viewStudents_Click);
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.Crimson;
            this.close.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.close.Location = new System.Drawing.Point(299, 269);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(96, 45);
            this.close.TabIndex = 11;
            this.close.Text = "Salir";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.exit);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(417, 325);
            this.ControlBox = false;
            this.Controls.Add(this.close);
            this.Controls.Add(this.viewStudents);
            this.Controls.Add(this.showEvidence);
            this.Controls.Add(this.profileButton);
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button profileButton;
        private System.Windows.Forms.Button showEvidence;
        private System.Windows.Forms.Button viewStudents;
        private System.Windows.Forms.Button close;
    }
}